import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import UploadPage from "./pages/UploadPage";
import ResultPage from "./pages/ResultPage";

function App() {
  const [userId, setUserId] = useState(null);
  const [uploadData, setUploadData] = useState(null);

  // ✅ Clear saved data when app first loads (prevents auto redirect)
  useEffect(() => {
    localStorage.removeItem("userId");
    localStorage.removeItem("userEmail");
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("userId");
    localStorage.removeItem("userEmail");
    setUserId(null);
  };

  return (
    <Router>
      <Routes>
        {/* Login Page */}
        <Route
          path="/"
          element={
            !userId ? (
              <LoginPage onLoginSuccess={setUserId} />
            ) : (
              <Navigate to="/upload" />
            )
          }
        />

        {/* Login Route */}
        <Route
          path="/login"
          element={
            !userId ? (
              <LoginPage onLoginSuccess={setUserId} />
            ) : (
              <Navigate to="/upload" />
            )
          }
        />

        {/* Register Route */}
        <Route
          path="/register"
          element={
            !userId ? (
              <RegisterPage onRegisterSuccess={setUserId} />
            ) : (
              <Navigate to="/upload" />
            )
          }
        />

        {/* Upload Route */}
        <Route
          path="/upload"
          element={
            userId ? (
              <UploadPage
                userId={userId}
                onUploadComplete={setUploadData}
                onLogout={handleLogout}
              />
            ) : (
              <Navigate to="/login" />
            )
          }
        />

        {/* Result Page */}
        <Route
          path="/result"
          element={
            uploadData ? (
              <ResultPage data={uploadData} />
            ) : (
              <Navigate to="/upload" />
            )
          }
        />
      </Routes>
    </Router>
  );
}

export default App;
