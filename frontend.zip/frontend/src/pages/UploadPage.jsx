import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

function UploadPage({ userId, onUploadComplete }) {
  const [file, setFile] = useState(null);
  const navigate = useNavigate();

  const handleUpload = async () => {
    if (!file) {
      alert("Select a PDF first!");
      return;
    }

    // ✅ Get logged-in user's email (stored in localStorage at login)
    const userEmail = localStorage.getItem("userEmail");

    const formData = new FormData();
    formData.append("file", file);
    formData.append("user_id", userId);
    formData.append("email", userEmail); // ✅ send email to backend

    try {
      console.log("Uploading...");
      const res = await axios.post("http://localhost:5000/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      console.log("Response from backend:", res.data);
      onUploadComplete(res.data);
      navigate("/result");
    } catch (err) {
      console.error("❌ Upload failed:", err);
      alert("Upload failed, check console for details!");
    }
  };

  return (
    <div style={{ padding: "20px", textAlign: "center" }}>
      <h2>📄 Upload Legal Document</h2>
      <input
        type="file"
        accept="application/pdf"
        onChange={(e) => setFile(e.target.files[0])}
        style={{ marginBottom: "15px" }}
      />
      <br />
      <button
        onClick={handleUpload}
        style={{
          padding: "10px 20px",
          backgroundColor: "#007bff",
          color: "white",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
        }}
      >
        Upload & Analyze
      </button>
    </div>
  );
}

export default UploadPage;
