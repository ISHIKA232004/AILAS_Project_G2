import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "../styles/form.css";

function RegisterPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleRegister = async () => {
    if (!name || !email || !password) {
      alert("Please fill all fields");
      return;
    }

    try {
      const res = await fetch("http://127.0.0.1:5000/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password }),
      });

      const data = await res.json();

      if (data.success) {
        alert("Registration successful 🎉");
        // ✅ Redirect user to login page after register
        navigate("/login");
      } else {
        alert(data.message || "Registration failed");
      }
    } catch (err) {
      console.error(err);
      alert("Error connecting to backend!");
    }
  };

  return (
    <div className="form-container">
      <h1 className="app-title">WELCOME</h1>
      <p className="app-subtitle">AILAS – AI Legal Analyzer & Summarizer</p>

      <h2>Register</h2>

      {/* ✅ Disable browser autofill */}
      <form
        onSubmit={(e) => e.preventDefault()}
        autoComplete="off"
        style={{ width: "100%" }}
      >
        <div className="input-field">
          <input
            type="text"
            placeholder="Full Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoComplete="off"
          />
        </div>

        <div className="input-field">
          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="off"
          />
        </div>

        <div className="input-field">
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="new-password"
          />
        </div>

        <button type="button" onClick={handleRegister}>
          Register
        </button>
      </form>

      <p className="switch-text">
        Already have an account?{" "}
        <Link to="/login" style={{ color: "#fff", textDecoration: "underline" }}>
          Login now
        </Link>
      </p>
    </div>
  );
}

export default RegisterPage;
