import React, { useState } from "react";
import { Link } from "react-router-dom";
import "../styles/form.css";

function LoginPage({ onLoginSuccess }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {
    if (!email || !password) {
      alert("Please fill all fields");
      return;
    }

    try {
      const res = await fetch("http://127.0.0.1:5000/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();
      if (data.success) {
        alert("Login successful 🎉");

        // ✅ Save login info for later use (UploadPage)
        localStorage.setItem("userEmail", email);
        localStorage.setItem("userId", data.user_id);

        onLoginSuccess(data.user_id);
      } else {
        alert(data.message || "Invalid credentials");
      }
    } catch (err) {
      console.error(err);
      alert("Login failed. Please check your backend connection.");
    }
  };

  return (
    <div className="form-container">
      <h1 className="app-title">WELCOME</h1>
      <p className="app-subtitle">AILAS – AI Legal Analyzer & Summarizer</p>

      <h2>Login</h2>

      {/* ✅ Disable browser autofill */}
      <form
        onSubmit={(e) => e.preventDefault()}
        autoComplete="off"
        style={{ width: "100%" }}
      >
        <div className="input-field">
          <input
            type="email"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="off"
          />
        </div>

        <div className="input-field">
          <input
            type="password"
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            autoComplete="new-password"
          />
        </div>

        <button type="button" onClick={handleLogin}>
          Login
        </button>
      </form>

      <p className="switch-text">
        Don’t have an account? <Link to="/register">Register here</Link>
      </p>
    </div>
  );
}

export default LoginPage;
