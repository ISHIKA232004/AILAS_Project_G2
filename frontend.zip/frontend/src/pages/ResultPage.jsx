import React from "react";
import { jsPDF } from "jspdf";

function ResultPage({ data }) {
  if (!data) {
    return (
      <div
        style={{
          textAlign: "center",
          padding: "80px",
          color: "white",
          background: "linear-gradient(to right, #6a11cb, #2575fc)",
          height: "100vh",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          alignItems: "center",
          fontSize: "1.3rem",
        }}
      >
        <h2>⚙️ Analyzing document...</h2>
        <p>Please wait while we generate the summary.</p>
      </div>
    );
  }

  const filename = data?.filename || "Unknown File";
  const metadata = data?.metadata || {};
  const summary = data?.summary || "No summary available.";
  const sections = Array.isArray(data?.sections) ? data.sections : [];

  const renderSummary = (summaryData) => {
    if (typeof summaryData === "string") {
      return <p>{summaryData}</p>;
    } else if (typeof summaryData === "object") {
      return (
        <div style={{ lineHeight: "1.8" }}>
          {Object.entries(summaryData).map(([key, value], i) => (
            <p key={i} style={{ marginBottom: "6px" }}>
              <b>{key}:</b> {String(value) || "N/A"}
            </p>
          ))}
        </div>
      );
    } else {
      return <p>No summary available.</p>;
    }
  };

  const saveAsPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(14);
    doc.text("AI Legal Assistant - Document Summary", 10, 10);

    doc.setFontSize(11);
    doc.text(`Filename: ${filename}`, 10, 25);
    doc.text(`Uploaded At: ${metadata.uploaded_at || "N/A"}`, 10, 35);
    doc.text(`Pages: ${metadata.pages || "N/A"}`, 10, 45);
    doc.text(`Total Characters: ${metadata.total_characters || "N/A"}`, 10, 55);

    doc.text("Document Summary:", 10, 70);

    let y = 80;
    if (typeof summary === "object") {
      Object.entries(summary).forEach(([key, value]) => {
        doc.text(`${key}: ${String(value)}`, 10, y);
        y += 10;
      });
    } else {
      const summaryLines = doc.splitTextToSize(String(summary), 180);
      doc.text(summaryLines, 10, y);
      y += summaryLines.length * 6;
    }

    sections.forEach((sec, i) => {
      if (y > 270) {
        doc.addPage();
        y = 20;
      }
      doc.setFontSize(12);
      doc.text(`${i + 1}. ${sec.title || "Untitled Section"}`, 10, y);
      y += 8;
      doc.setFontSize(11);

      const addWrappedText = (label, value) => {
        const text = Array.isArray(value) ? value.join(", ") : value || "N/A";
        const lines = doc.splitTextToSize(`${label} ${text}`, 180);
        doc.text(lines, 10, y);
        y += lines.length * 5 + 5;
      };

      addWrappedText("Summary:", sec.summary);
      addWrappedText("Entities:", sec.entities);
      addWrappedText("Keywords:", sec.keywords);
      addWrappedText("Risks:", sec.risks);
      addWrappedText("Obligations:", sec.obligations);
    });

    doc.save(`${filename}_Analysis.pdf`);
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        width: "100%",
        background: "linear-gradient(to right, #6a11cb, #2575fc)",
        color: "white",
        padding: "50px 80px",
        fontFamily: "Arial, sans-serif",
        overflowY: "auto",
      }}
    >
      <h2 style={{ fontSize: "2rem", marginBottom: "25px" }}>
        📘 Document Analysis
      </h2>

      <p><b>Filename:</b> {filename}</p>
      <p><b>Uploaded At:</b> {metadata.uploaded_at || "N/A"}</p>
      <p><b>Pages:</b> {metadata.pages || "N/A"}</p>
      <p><b>Total Characters:</b> {metadata.total_characters || "N/A"}</p>

      <div
        style={{
          marginTop: "30px",
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "40px",
          alignItems: "start",
        }}
      >
        {/* Left Column */}
        <div>
          <h3 style={{ marginBottom: "10px" }}>📝 Document Summary</h3>
          <div
            style={{
              background: "white",
              color: "black",
              padding: "25px",
              borderRadius: "12px",
              boxShadow: "0 6px 10px rgba(0,0,0,0.3)",
              minHeight: "250px",
            }}
          >
            {renderSummary(summary)}
          </div>
        </div>

        {/* Right Column */}
        <div>
          <h3 style={{ marginBottom: "10px" }}>📄 Sections Breakdown</h3>
          {sections.length > 0 ? (
            sections.map((sec, index) => (
              <div
                key={index}
                style={{
                  marginBottom: "20px",
                  background: "white",
                  color: "black",
                  padding: "20px",
                  borderRadius: "12px",
                  boxShadow: "0 6px 10px rgba(0,0,0,0.25)",
                }}
              >
                <h4 style={{ marginBottom: "10px" }}>
                  {index + 1}. {sec.title || "Untitled Section"}
                </h4>
                <p><b>Summary:</b> {sec.summary || "N/A"}</p>
                <p><b>Entities:</b> {Array.isArray(sec.entities) ? sec.entities.join(", ") : "N/A"}</p>
                <p><b>Keywords:</b> {Array.isArray(sec.keywords) ? sec.keywords.join(", ") : "N/A"}</p>
                <p><b>Risks:</b> {Array.isArray(sec.risks) ? sec.risks.join(", ") : "N/A"}</p>
                <p><b>Obligations:</b> {Array.isArray(sec.obligations) ? sec.obligations.join(", ") : "N/A"}</p>
              </div>
            ))
          ) : (
            <p>No sections available.</p>
          )}
        </div>
      </div>

      <div style={{ textAlign: "center", marginTop: "50px" }}>
        <button
          onClick={saveAsPDF}
          style={{
            padding: "14px 25px",
            backgroundColor: "#007BFF",
            color: "white",
            border: "none",
            borderRadius: "10px",
            cursor: "pointer",
            fontSize: "1rem",
            fontWeight: "bold",
            transition: "0.3s",
          }}
          onMouseOver={(e) => (e.target.style.backgroundColor = "#0056b3")}
          onMouseOut={(e) => (e.target.style.backgroundColor = "#007BFF")}
        >
          💾 Download Report
        </button>
      </div>
    </div>
  );
}

export default ResultPage;
