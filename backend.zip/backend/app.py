from flask import Flask, request, jsonify, send_file
from flask_cors import CORS, cross_origin
import fitz  # PyMuPDF
from transformers import pipeline
import spacy
import re
from datetime import datetime
from collections import Counter
import os
import mysql.connector
from PIL import Image
import pytesseract
import io
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.units import inch

# ⬇️ your summarizer.py functions
from summarizer import summarize_document, detect_document_type

# Tesseract OCR path
pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}}, supports_credentials=True)

# ---------------------------------------------------------
# DB CONNECTION
# ---------------------------------------------------------
def get_db_connection():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password="password",
        database="AILAS"
    )

# ---------------------------------------------------------
# REGISTER
# ---------------------------------------------------------
@app.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    name = data.get("name")
    email = data.get("email")
    password = data.get("password")

    try:
        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE email=%s", (email,))
        if cursor.fetchone():
            return jsonify({"success": False, "message": "Email already registered"})

        cursor.execute("INSERT INTO users (name, email, password) VALUES (%s, %s, %s)",
                       (name, email, password))
        conn.commit()
        return jsonify({"success": True})

    except:
        return jsonify({"success": False, "message": "Server error"})
    finally:
        cursor.close()
        conn.close()

# ---------------------------------------------------------
# LOGIN
# ---------------------------------------------------------
@app.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    email = data.get("email")
    password = data.get("password")

    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM users WHERE email=%s AND password=%s", (email, password))
        user = cursor.fetchone()

        if user:
            return jsonify({"success": True, "user_id": user[0]})
        return jsonify({"success": False, "message": "Invalid email or password"})

    except:
        return jsonify({"success": False, "message": "Server error"})
    finally:
        cursor.close()
        conn.close()

# ---------------------------------------------------------
# LOAD NLP MODELS
# ---------------------------------------------------------
summarizer = pipeline("summarization", model="sshleifer/distilbart-cnn-12-6", truncation=True)
nlp = spacy.load("en_core_web_sm")

UPLOAD_FOLDER = "uploads"
REPORT_FOLDER = "reports"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(REPORT_FOLDER, exist_ok=True)

# ---------------------------------------------------------
# PDF TEXT EXTRACTION
# ---------------------------------------------------------
def extract_text_from_pdf(pdf_path):
    text = ""
    doc = fitz.open(pdf_path)

    for page in doc:
        page_text = page.get_text("text")
        if not page_text.strip():
            pix = page.get_pixmap()
            img = Image.open(io.BytesIO(pix.tobytes("png")))
            page_text = pytesseract.image_to_string(img)

        text += page_text + "\n"

    cleaned = re.sub(r'[^a-zA-Z0-9\s,.!?%()\-–—:;/&]', '', text)
    cleaned = re.sub(r'\s+', ' ', cleaned)
    return cleaned.strip()

# ---------------------------------------------------------
# AI SUMMARY
# ---------------------------------------------------------
def chunk_text(text, max_words=400):
    words = text.split()
    return [" ".join(words[i:i + max_words]) for i in range(0, len(words), max_words)]

def generate_summary(text):
    if not text.strip():
        return "⚠️ No text found"

    chunks = chunk_text(text, 200)
    summaries = []

    for chunk in chunks:
        try:
            result = summarizer(chunk, truncation=True, max_length=150, min_length=40, do_sample=False)
            summaries.append(result[0]["summary_text"])
        except:
            summaries.append(chunk[:250])
    return " ".join(summaries)

# ---------------------------------------------------------
# SECTION IDENTIFIER
# ---------------------------------------------------------
def identify_clauses_sections(text):
    pattern = r'\b(Preamble|Abstract|Introduction|System Design|Implementation|Testing|Optimization|Conclusion|Case Studies|Objective|Scope|Acknowledgement|Literature Review)\b'
    sections = []
    current = {"title": "Preamble", "full_content": ""}

    for line in re.split(r'\.\s+|\n', text):
        line = line.strip()
        if not line:
            continue

        match = re.search(pattern, line, re.IGNORECASE)
        if match:
            if current["full_content"]:
                sections.append(current)
            current = {"title": match.group(1), "full_content": ""}
        else:
            current["full_content"] += " " + line

    if current["full_content"]:
        sections.append(current)

    return sections if sections else [{"title": "Full Document", "full_content": text}]

# ---------------------------------------------------------
# ENTITY + KEYWORDS + RISKS
# ---------------------------------------------------------
def extract_entities_keywords(text):
    doc = nlp(text)
    ents = list(set(ent.text for ent in doc.ents))
    keys = [t.text for t in doc if t.pos_ in ("NOUN", "PROPN")]
    common = [w for w, _ in Counter(keys).most_common(10)]
    return ents, common

def detect_risks_obligations(text):
    risks = [w for w in ["penalty", "liability", "breach", "risk"] if w in text.lower()]
    obligations = [w for w in ["must", "shall", "required", "obligation"] if w in text.lower()]
    return risks or ["No major risks"], obligations or ["No explicit obligations"]

# ---------------------------------------------------------
# UPLOAD + ANALYZE
# ---------------------------------------------------------
@app.route('/upload', methods=['POST'])
@cross_origin()
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files['file']
    pdf_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(pdf_path)

    full_text = extract_text_from_pdf(pdf_path)

    if len(full_text) < 50:
        return jsonify({"error": "Not enough text"}), 400

    # ---------------------------------------------------------
    # ⭐ FIXED DOCUMENT TYPE DETECTION (BANKING PRIORITY CORRECTED)
    # ---------------------------------------------------------
    document_type = "General"
    t = full_text.lower()

    # 1️⃣ FIR (unique)
    if re.search(r"\bfir\b|first information report", t):
        document_type = "FIR"

    # # 2️⃣ ⭐ BANKING (very strict + placed BEFORE policy)
    # elif re.search(r"(loan account number|sanction no|home loan|emi|rate of interest|tenure)", 
    #             t, re.IGNORECASE):
    #     document_type = "Banking"
    elif (
        re.search(r"(Loan Account Number|Sanction No|Rate of Interest|Home Loan|EMI)", 
                full_text, re.IGNORECASE)
        and not re.search(r"(Policy|Coverage|Premium|Insurance|Claim Process)", 
                        full_text, re.IGNORECASE)
    ):
        document_type = "Banking"


    # 3️⃣ POLICY (placed AFTER banking)
    elif re.search(r"(policyholder|premium|coverage|claim process|insurance)", 
                t, re.IGNORECASE):
        document_type = "Policy"

    # 4️⃣ REGISTRY (strict)
    elif re.search(r"(sub-registrar|stamp duty|registration fees|registry no|sale deed)", 
                t, re.IGNORECASE):
        document_type = "Registry"

    # 5️⃣ BUILDER
    elif re.search(r"(builder|project name|carpet area|super built-up|construction status|rera)", 
                t, re.IGNORECASE):
        document_type = "Builder Property"

    else:
        document_type = "General"

    print("📌 Detected:", document_type)




    # ---------------------------------------------------------
    # CUSTOM SUMMARY
    # ---------------------------------------------------------
    custom_summary = summarize_document(document_type, full_text)

    # ---------------------------------------------------------
    # AI SUMMARY + SECTIONS
    # ---------------------------------------------------------
    ai_summary = generate_summary(full_text)
    sections = identify_clauses_sections(full_text)

    for s in sections:
        s["summary"] = generate_summary(s["full_content"])
        s["entities"], s["keywords"] = extract_entities_keywords(s["full_content"])
        s["risks"], s["obligations"] = detect_risks_obligations(s["full_content"])

    metadata = {
        "filename": file.filename,
        "pages": len(fitz.open(pdf_path)),
        "uploaded_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total_characters": len(full_text)
    }

    return jsonify({
        "status": "success",
        "document_type": document_type,
        "summary": custom_summary,
        "ai_summary": ai_summary,
        "sections": sections,
        "metadata": metadata
    })

# ---------------------------------------------------------
# PDF DOWNLOAD
# ---------------------------------------------------------
@app.route('/download', methods=['POST'])
def download_pdf():
    data = request.get_json()
    filename = data.get("filename", "Report")
    summary = data.get("summary", "")
    sections = data.get("sections", [])
    metadata = data.get("metadata", {})

    report_path = os.path.join(REPORT_FOLDER, f"{filename}_Report.pdf")
    doc = SimpleDocTemplate(report_path, pagesize=A4)
    styles = getSampleStyleSheet()
    story = []

    story.append(Paragraph("<b>📘 AI Legal Assistant - Report</b>", styles["Title"]))
    story.append(Spacer(1, 20))

    meta = f"""
    <b>Filename:</b> {metadata.get('filename')}<br/>
    <b>Uploaded:</b> {metadata.get('uploaded_at')}<br/>
    <b>Pages:</b> {metadata.get('pages')}<br/>
    <b>Total Characters:</b> {metadata.get('total_characters')}<br/>
    """
    story.append(Paragraph(meta, styles["Normal"]))
    story.append(Spacer(1, 20))

    story.append(Paragraph("<b>Summary</b>", styles["Heading2"]))
    story.append(Paragraph(str(summary), styles["Normal"]))
    story.append(Spacer(1, 20))

    for i, sec in enumerate(sections, start=1):
        story.append(Paragraph(f"<b>{i}. {sec['title']}</b>", styles["Heading2"]))
        story.append(Paragraph(sec["summary"], styles["Normal"]))
        story.append(Spacer(1, 10))

    doc.build(story)
    return send_file(report_path, as_attachment=True)

# ---------------------------------------------------------
# RUN SERVER
# ---------------------------------------------------------
if __name__ == "__main__":
    print("🚀 Server running...")
    app.run(host="127.0.0.1", port=5000, debug=True)
