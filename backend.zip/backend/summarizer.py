import re

# ---------------------------------------------------------
# 🔹 Helper Function
# ---------------------------------------------------------
def extract_pattern(text, pattern, default="Not found"):
    match = re.search(pattern, text, re.IGNORECASE)
    if not match:
        return default
    return match.group(1).strip() if match.lastindex else match.group(0).strip()


# ---------------------------------------------------------
# 🔹 FIR Summarizer
# ---------------------------------------------------------
def summarize_fir(text):
    return {
        "Complainant": extract_pattern(text, r"Name\s*:\s*([A-Z][a-z]+(?:\s[A-Z][a-z]+)*)"),
        "Crime Type": extract_pattern(text, r"(Theft|Murder|Fraud|Assault|Robbery|Cheating|Forgery|Kidnapping|Cybercrime)"),
        "Date/Time": extract_pattern(text, r"Date and hour of Occurrence\s*:\s*([\d\/,:\sAPM]+)"),
        "Investigation Steps": extract_pattern(text, r"(CCTV|patrolling|investigation|team|search|witness|statement)"),
        "Law Section": extract_pattern(text, r"Section\s*\d+\s*[A-Z]*"),
        "Place": extract_pattern(text, r"Location\s*:\s*([\w\s,]+)"),
        "Property Lost": extract_pattern(text, r"(laptop|cash|jewellery|mobile|vehicle|money|documents|gold|bag)")
    }


# ---------------------------------------------------------
# 🔹 Registry Summarizer
# ---------------------------------------------------------
def summarize_registry(text):
    return {
        "Seller": extract_pattern(text, r"Seller[:\-]?\s*([A-Z][a-z]+\s+[A-Z][a-z]+)"),

        "Buyer": extract_pattern(text, r"Buyer[:\-]?\s*([A-Z][a-z]+\s+[A-Z][a-z]+)"),

        "Property Details": extract_pattern(
            text,
            r"(Flat\s*No\.?\s*[\w\-]+.*?Sq\.?\s*Ft)",
            default="Details Not Found"
        ),

        # ✅ Payment Amount only
        "Payment Amount": extract_pattern(
            text,
            r"(?:Payment Amount|Total Consideration Amount|Payment)[:\-]?\s*(Rs\.?\s*[\d,]+)"
        ),

        # ✅ Payment Mode only
        "Payment Mode": extract_pattern(
            text,
            r"Payment Mode[:\-]?\s*([\w\s]+)"
        ),

        # 🔹 If user writes like → Payment: Paid via Bank Transfer
        #    This will catch “Bank Transfer” also.
        "Payment Mode (Alt)": extract_pattern(
            text,
            r"Payment[:\-]?\s*(?:Paid via|Through)?\s*([\w\s]+)",
            default="Not specified"
        ),

        "Fees": extract_pattern(
            text,
            r"(Stamp Duty|Registration Fees)[:\-]?\s*(Rs\.?\s*[\d,]+)"
        ),

        "Registry Date": extract_pattern(
            text,
            r"Date[:\-]?\s*(\d{1,2}\s*[A-Za-z]+\s*\d{4})"
        )
    }


# ---------------------------------------------------------
# 🔹 Policy Summarizer
# ---------------------------------------------------------
def summarize_policy(text):
    return {
        "Policy Name": extract_pattern(text, r"(?:Policy Name|Plan)[:\-]?\s*([A-Za-z\s]+)"),
        "Premium": extract_pattern(text, r"Premium[:\-]?\s*(Rs\.?\s*[\d,]+)"),
        "Coverage": extract_pattern(text, r"Coverage[:\-]?\s*([\w\s,]+)"),
        "Term": extract_pattern(text, r"(?:Tenure|Term)[:\-]?\s*(\d+\s*(years|months)?)"),
        "Claim Process": extract_pattern(text, r"(?:Claim Process|Procedure)[:\-]?\s*([\w\s,]+)"),
        "Hidden Charges": extract_pattern(text, r"(?:Hidden Charges|Extra Fees)[:\-]?\s*([\w\s,]+)", default="None mentioned")
    }


# ---------------------------------------------------------
# 🔹 Builder Property Summarizer
# ---------------------------------------------------------
def summarize_builder_property(text):
    return {
        "Project Name": extract_pattern(text, r"(?:Project Name|Scheme)[:\-]?\s*([\w\s]+)"),
        "Payment Plan": extract_pattern(text, r"(?:Payment Plan|Installment)[:\-]?\s*([\w\s%]+)"),
        "Construction Status": extract_pattern(text, r"(?:Construction Status|Phase)[:\-]?\s*([\w\s]+)"),
        "Area": extract_pattern(text, r"(?:Area|Carpet|Super Built Up)[:\-]?\s*([\d\s\w]+)"),
        "Agreement Points": extract_pattern(text, r"(?:Agreement|Terms|Conditions)[:\-]?\s*([\w\s,]+)")
    }


# ---------------------------------------------------------
# 🔹 Banking Summarizer (Final + Clean + Accurate)
# ---------------------------------------------------------
def summarize_banking(text):
    summary = {
        "Bank Name": "Not found",
        "Loan Amount": "Not found",
        "Interest Rate": "Not found",
        "Tenure": "Not found",
        "Collateral": "Not found",
        "Obligations": "Not found"
    }

    # Bank Name
    bank = re.search(r"(Bank of India|SBI|ICICI Bank|HDFC Bank)", text, re.IGNORECASE)
    if bank:
        summary["Bank Name"] = bank.group(1)

    # Loan Amount
    loan = re.search(r"Loan Amount\s*[:\-]?\s*Rs\.?\s*([\d,]+)", text, re.IGNORECASE)
    if loan:
        summary["Loan Amount"] = loan.group(1)

    # Interest Rate
    interest = re.search(r"Rate of Interest\s*[:\-]?\s*([\d\.]+%)", text, re.IGNORECASE)
    if interest:
        summary["Interest Rate"] = interest.group(1)

    # Tenure
    tenure = re.search(r"Tenure\s*[:\-]?\s*(\d+\s*years|\d+\s*months)", text, re.IGNORECASE)
    if tenure:
        summary["Tenure"] = tenure.group(1)

    # Collateral: capture until next numbered point OR Obligations
    collateral = re.search(r"Collateral\s*[:\-]?\s*((?:.|\n)*?)(?:\n\d+\.|\nObligations|$)", text, re.IGNORECASE)
    if collateral:
        summary["Collateral"] = " ".join(collateral.group(1).split())

    # Obligations: capture until next point or end
    obligations = re.search(r"Obligations\s*[:\-]?\s*((?:.|\n)*?)(?:\n\d+\.|$)", text, re.IGNORECASE)
    if obligations:
        summary["Obligations"] = " ".join(obligations.group(1).split())

    return summary


# ---------------------------------------------------------
# 🔹 Auto Detect Document Type (Final & Robust)
# ---------------------------------------------------------
def detect_document_type(text):
    text_lower = text.lower()

    # FIR
    if "first information report" in text_lower or "fir" in text_lower:
        return "fir"

    # Banking (strong patterns)
    if re.search(r"loan amount|rate of interest|sanction|emi|home loan|tenure", text_lower):
        return "banking"

    # Registry (strict)
    if re.search(r"\bseller name\b|\bbuyer\b|\bproperty no\b|\bregistry\b|\bstamp duty\b", text_lower):
        return "registry"

    # Policy
    if re.search(r"policy name|premium|coverage|claim process", text_lower):
        return "policy"

    # Builder Property
    if re.search(r"project name|payment plan|construction status|carpet area", text_lower):
        return "builder property"

    return "unknown"


# ---------------------------------------------------------
# 🔹 Controller Function
# ---------------------------------------------------------
def summarize_document(document_type, extracted_text):
    document_type = document_type.strip().lower()

    # Auto detection mode
    if document_type == "auto":
        document_type = detect_document_type(extracted_text)

    if document_type == "fir":
        return summarize_fir(extracted_text)
    elif document_type == "registry":
        return summarize_registry(extracted_text)
    elif document_type == "policy":
        return summarize_policy(extracted_text)
    elif document_type == "builder property":
        return summarize_builder_property(extracted_text)
    elif document_type == "banking":
        return summarize_banking(extracted_text)
    else:
        return {"message": "Unsupported or unknown document type."}
